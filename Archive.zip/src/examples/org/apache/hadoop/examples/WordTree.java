package org.apache.hadoop.examples;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class WordTree {
	NodeWritable root;
	
	public void build(String path) throws FileNotFoundException {
		File file = new File(path);
		Scanner scan = new Scanner(file);
		
		
		while (scan.hasNextLine()) {
			String line = scan.nextLine();
			String word = line.trim();
			NodeWritable newNode = new NodeWritable(word, null, null);
			while (scan.hasNextLine()) {
				line = scan.nextLine();
				if (line.charAt(0) == '*')
					break;
				Record newRecord = new Record();
				newRecord.gatherInfoFromString(line);
				newNode.addRecord(newRecord);
			}
			//System.out.println(newNode);
			insert(newNode);
		}
	}
	
	public void insert(NodeWritable newNode) {
//		Scanner  scan = new Scanner(System.in);
//		scan.next();
		root = insertR(root, newNode);
		if (root.getLeft() != null)
		System.out.println("l " + root.getLeft().getSubtreeSize());
		if (root.getRight() != null)
		System.out.println("r " + root.getRight().getSubtreeSize());

	}
	
	public NodeWritable insertR(NodeWritable root, NodeWritable newNode) {
		if (root == null)
			return newNode;
		int compareValue = root.getWord().compareToIgnoreCase(newNode.getWord());
		if (compareValue == 0) {
			root.merge(newNode);
			return root;
		}
		root.setSubtreeSize(root.getSubtreeSize() + 1);
		if (compareValue < 0) 
			root.setRight(insertR(root.getRight(), newNode));
		if (compareValue > 0) 
			root.setLeft(insertR(root.getLeft(), newNode));
		
		int leftCount = 0;
		int rightCount = 0;
		
		if (root.getLeft() != null)
			leftCount = root.getLeft().getSubtreeSize();
		if (root.getRight() != null)
			rightCount = root.getRight().getSubtreeSize();
		
		if (leftCount - rightCount > 1)
			root = rotateRight(root);
		else if (leftCount - rightCount < -1)
			root = rotateLeft(root);
		
		return root;
	}
	
	
	
	private NodeWritable rotateRight(NodeWritable root) {
		NodeWritable pivot = root.getLeft();
		root.setLeft(pivot.getRight());
		pivot.setRight(root);
		updateSubtreeCount(root);
		updateSubtreeCount(pivot);
		
		return pivot;
	}


	private NodeWritable rotateLeft(NodeWritable root) {
		NodeWritable pivot = root.getRight();
		root.setRight(pivot.getLeft());
		pivot.setLeft(root);
		updateSubtreeCount(root);
		updateSubtreeCount(pivot);
		
		return pivot;
	}


	private void updateSubtreeCount(NodeWritable node) {
		int leftCount = 0;
		int rightCount = 0;
		
		if (node.getLeft() != null)
			leftCount = node.getLeft().getSubtreeSize();
		if (node.getRight() != null)
			rightCount = node.getRight().getSubtreeSize();
		
		node.setSubtreeSize(leftCount + rightCount + 1);
	}
	
	public WordTree() {
		root = null;
	}
	
	public void print() {
		//printR(root);
		System.out.println(root.getLeft().getSubtreeSize());
		System.out.println(root.getRight().getSubtreeSize());
		System.out.println(root.getSubtreeSize());

	}

	private void printR(NodeWritable node) {
		if (node == null)
			return;
		printR(node.getLeft());
		System.out.println(node);
		printR(node.getRight());
	}
}
