package org.apache.hadoop.examples;

import java.io.IOException;
import java.util.StringTokenizer;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.examples.NodeWritable;

public class BookReader {

	public static class TokenizerMapper extends
			Mapper<Object, Text, Text, NodeWritable> {

		private Text word = new Text();
		
		//info = "bookName" \n lineNumber \n words
		public void map(Object key, Text info,
				Context context) throws IOException, InterruptedException {
			String delimiters = " \"(){}[],.!?-_=+><:;/*&^%$#@";
			StringTokenizer itr = new StringTokenizer(info.toString());

			String bookName = itr.nextToken("\"");
			itr.nextToken(" ");
			int lineNumber = Integer.parseInt(itr.nextToken(delimiters));
			
			while (itr.hasMoreTokens()) {
				NodeWritable node = new NodeWritable();
				node.addRecord(bookName, lineNumber);
				word.set(itr.nextToken().toLowerCase());
				node.setWord(word.toString());
				context.write(word, node);
			}
			
		}
	}

	public static class NodeReducer extends
			Reducer<Text, NodeWritable, Text, NodeWritable> {

		public void reduce(Text word, Iterable<NodeWritable> nodes,
				Context context) throws IOException, InterruptedException {
			NodeWritable nodeUnion = new NodeWritable();

			nodeUnion.setWord(word.toString());
			for (NodeWritable node: nodes) {
				nodeUnion.merge(node);
			}
			
			context.write(word, nodeUnion);
		}
	}

	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		PreProcessor preProcessor = new PreProcessor();
		
		preProcessor.duplicateDir(args[0], "./tmp");
		
		Job job = new Job(conf, "wordtree");
		job.setJarByClass(BookReader.class);
		job.setMapperClass(TokenizerMapper.class);
		job.setCombinerClass(NodeReducer.class);
		job.setReducerClass(NodeReducer.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(NodeWritable.class);
		FileInputFormat.addInputPath(job, new Path("./tmp"));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		if (job.waitForCompletion(true)) {
			WordTree wordTree = new WordTree();
			wordTree.build("./"+args[1] + "/part-r-00000");
			wordTree.print();
			System.exit(0);
		}
		System.exit(1);
	}
}
