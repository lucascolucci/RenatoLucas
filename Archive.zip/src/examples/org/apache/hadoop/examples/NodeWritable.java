package org.apache.hadoop.examples;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.io.Writable;

public class NodeWritable implements Writable {
	private String word;
	private List<Record> records;
	private NodeWritable left;
	private NodeWritable right;
	private int subtreeSize;

	public void setWord(String word) {
		this.word = word;
	}

	public String getWord() {
		return word;
	}
	
	public void setRecord(List<Record> newList) { 
		records = newList;
	}

	public List<Record> getRecords() {
		return records;
	}
	
	public void setLeft(NodeWritable left) {
		this.left = left;
	}
	
	public NodeWritable getLeft() {
		return left;
	}
	
	public void setRight(NodeWritable right) {
		this.right = right;
	}
	
	public NodeWritable getRight() {
		return right;
	}
	
	public void setSubtreeSize(int subtreeSize) {
		this.subtreeSize = subtreeSize;
	}
	
	public int getSubtreeSize() {
		return subtreeSize;
	}
	
	public void addRecord(String bookName, int line) {
		boolean bookAlreadyExists = false;
		int recordIndex = 0;
		for (Record record : records)
			if (record.getBook().equalsIgnoreCase(bookName)) {
				bookAlreadyExists = true;
				recordIndex = records.indexOf(record);
				break;
			}
		Record record;
		if (bookAlreadyExists) {
			record = records.get(recordIndex);
			record.addLine(line);
		} else {
			record = new Record(bookName);
			record.addLine(line);
			records.add(record);
		}
	}
	public void addRecord(Record record) {
		records.add(record);
	}

	@Override
	public void write(DataOutput out) throws IOException {
		out.writeBytes(word + "\n"); 
		out.writeInt(records.size());
		for (Record record : records)
			record.writeOut(out);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		word = in.readLine(); 
		records = new ArrayList<Record>();
		int numberOfRecords = in.readInt();
		for (int i = 0; i < numberOfRecords; i++) {
			Record record = new Record();
			record.readIn(in);
			records.add(record);
		}
	}

	public synchronized void merge(NodeWritable targetNode) {

		if (!this.word.contentEquals(targetNode.getWord())) 
			return;
		
		if (this.records.isEmpty()) {
			this.records.addAll(targetNode.getRecords());
			return;
		}
		
		List<Record> recordsToAdd = new ArrayList<Record>();
		for (Record targetRecord : targetNode.getRecords()) {
			boolean shouldAdd = true;

			for (Record thisRecord : this.records) {
				if (thisRecord.getBook().equalsIgnoreCase(targetRecord.getBook())) {
					thisRecord.addLines(targetRecord.getLines());
					shouldAdd = false;
					break;
				} 
			}
			if (shouldAdd)
				recordsToAdd.add(targetRecord);
			
		}
		records.addAll(recordsToAdd);
//		records.addAll(targetNode.getRecords());
	}

	public static NodeWritable read(DataInput in) throws IOException {
		NodeWritable n = new NodeWritable();
		n.readFields(in);
		return n;
	}

	public NodeWritable() {
		records = new ArrayList<Record>();
		this.subtreeSize = 1;
	}
	
	public NodeWritable(String word, NodeWritable left, NodeWritable right) {
		records = new ArrayList<Record>();
		this.word = word;
		this.left = left;
		this.right = right;
		this.subtreeSize = 1;
	}

	@Override
	public String toString() {
		String toPrint = "\n";
		if (records.isEmpty())
			toPrint = toPrint + "is Empty.";
		for (Record record : records) {
			toPrint = toPrint + record.toString() + "\n";
		}
		toPrint = toPrint + "***********************************";
		return toPrint;

	}

	

}
