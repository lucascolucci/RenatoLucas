package org.apache.hadoop.examples;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class PreProcessor {
	
	
	public void duplicateDir(String sourcePath, String destinationPath) throws IOException {
		File sourceFolder = new File(sourcePath);
		File destinationFolder = new File(destinationPath);
		
		destinationFolder.mkdir();
		
		if(!sourceFolder.isDirectory())
			return;
		for(File file: sourceFolder.listFiles()) {
			duplicateFile(file, destinationFolder);
		}
	}

	private void duplicateFile(File file, File destinationFolder) throws IOException {
		String bookName = "\"" + file.getName() +"\"";
		FileWriter duplicatedFile = new FileWriter(destinationFolder.getPath() + "/" + file.getName());
		Scanner scan = new Scanner(file);
		
		int lineNumber = 1;
		while (scan.hasNextLine()) {
			String line = scan.nextLine();
			line = bookName + " " + lineNumber + " " + line + "\n";
			duplicatedFile.write(line);
			lineNumber++;
		}
		duplicatedFile.close();
	}
}
