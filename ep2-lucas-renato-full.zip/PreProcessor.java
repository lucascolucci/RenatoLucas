/***********************************************************/
/** MAC0431 - Computacao paralela e distribuida           **/
/** IME-USP - Segundo Semestre de 2012                    **/
/**                                                       **/
/** Nome: Lucas Rodrigues Colucci   - N USP 6920251       **/
/** Nome: Renato Lerac Correa de Sa - N USP 3752273       **/
/** Professor Alfredo Goldman                             **/
/**                                                       **/
/** Segundo Exercicio-Programa - Hadoop                   **/
/** Arquivo: PreProcessor.java                            **/
/***********************************************************/

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class PreProcessor {

    public void duplicateDir(String sourcePath, String destinationPath)
            throws IOException {
        File sourceFolder = new File(sourcePath);
        File destinationFolder = new File(destinationPath);

        destinationFolder.mkdir();

        if (!sourceFolder.isDirectory())
            return;
        for (File file : sourceFolder.listFiles()) {
            duplicateFile(file, destinationFolder);
        }
    }

    private void duplicateFile(File file, File destinationFolder)
            throws IOException {
        String bookName = "\"" + file.getName() + "\"";
        FileWriter duplicatedFile = new FileWriter(destinationFolder.getPath()
                + "/" + file.getName());
        Scanner scan = new Scanner(file);

        int lineNumber = 1;
        while (scan.hasNextLine()) {
            String line = scan.nextLine();
            line = bookName + " " + lineNumber + " " + line + "\n";
            duplicatedFile.write(line);
            lineNumber++;
        }
        duplicatedFile.close();
    }

    public void clean(String path) {
        File folder = new File(path);
        if (folder != null) {
            for (File file : folder.listFiles()) {
                file.delete();
            }
            folder.delete();
        }
    }
}
