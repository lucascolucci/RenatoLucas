/***********************************************************/
/** MAC0431 - Computacao paralela e distribuida           **/
/** IME-USP - Segundo Semestre de 2012                    **/
/**                                                       **/
/** Nome: Lucas Rodrigues Colucci   - N USP 6920251       **/
/** Nome: Renato Lerac Correa de Sa - N USP 3752273       **/
/** Professor Alfredo Goldman                             **/
/**                                                       **/
/** Segundo Exercicio-Programa - Hadoop                   **/
/** Arquivo: Record.java                                  **/
/***********************************************************/

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

public class Record {
	private String book;
	private List<Integer> lines;
	
	public Record(String book) {
		this.setBook(book);
		lines = new ArrayList<Integer>(); 
	}

	public Record() {
		lines = new ArrayList<Integer>();
	}
	
	public String getBook() {
		return book;
	}

	public void setBook(String book) {
		this.book = book;
	}

	public void addLine(Integer line) {
		if (!lines.contains(line)) {
			int i;
			for (i = 0; i < lines.size(); i++)
				if (lines.get(i) > line)
					break;
			lines.add(i, line);
		}
	}
	
	public void addLines(List<Integer> lines) {
		for (Integer line: lines)
			addLine(line);
	}

	public List<Integer> getLines() {
		return lines;
	}
	
	public void removeLine(Integer line) {
		lines.remove(line);
	}

	public void writeOut(DataOutput out) {
		try {
			out.writeBytes(book + "\n");
			out.writeInt(lines.size());
			for (Integer line: lines) {
				out.writeInt(line);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

	public void readIn(DataInput in) {
		try {
			book = in.readLine();
			int numberOfLines = in.readInt();
			for (int i = 0; i < numberOfLines; i++)
				lines.add(in.readInt());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void gatherInfoFromString(String string) {
		Scanner scanner = new Scanner(string);
		Pattern p = Pattern.compile(".+[.]txt");
		book = scanner.next(p);
		while (scanner.hasNextInt()) {
			lines.add(scanner.nextInt());
		}
		
	}
	
	@Override
	public String toString() {
		String toPrint = book + " ";
		for (Integer line: lines)
			toPrint = toPrint + line + " ";
		return toPrint;	
	}
}
