/***********************************************************/
/** MAC0431 - Computacao paralela e distribuida           **/
/** IME-USP - Segundo Semestre de 2012                    **/
/**                                                       **/
/** Nome: Lucas Rodrigues Colucci   - N USP 6920251       **/
/** Nome: Renato Lerac Correa de Sa - N USP 3752273       **/
/** Professor Alfredo Goldman                             **/
/**                                                       **/
/** Segundo Exercicio-Programa - Hadoop                   **/
/** Arquivo: WordTree.java                                **/
/***********************************************************/

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class WordTree {
    NodeWritable root;

    public void build(String path) throws FileNotFoundException {
        File file = new File(path);
        Scanner scan = new Scanner(file);

        while (scan.hasNextLine()) {
            String line = scan.nextLine();
            String word = line.trim();
            NodeWritable newNode = new NodeWritable(word, null, null);
            while (scan.hasNextLine()) {
                line = scan.nextLine();
                if (line.charAt(0) == '*')
                    break;
                Record newRecord = new Record();
                newRecord.gatherInfoFromString(line);
                newNode.addRecord(newRecord);
            }
            insert(newNode);
        }
        System.out.println("Construcao da arvore finalizada!\n");
    }

    public void insert(NodeWritable newNode) {
        root = insertR(root, newNode);
    }

    public NodeWritable insertR(NodeWritable root, NodeWritable newNode) {
        if (root == null)
            return newNode;
        int compareValue = root.getWord()
                .compareToIgnoreCase(newNode.getWord());
        if (compareValue == 0) {
            root.merge(newNode);
            return root;
        }

        if (compareValue < 0) {
            root.setRight(insertR(root.getRight(), newNode));
            root.setSubtreeSize(root.getRight().getSubtreeSize() + 1);
        } else if (compareValue > 0) {
            root.setLeft(insertR(root.getLeft(), newNode));
            root.setSubtreeSize(root.getLeft().getSubtreeSize() + 1);
        }

        int leftCount = 0;
        int rightCount = 0;

        if (root.getLeft() != null)
            leftCount = root.getLeft().getSubtreeSize();
        if (root.getRight() != null)
            rightCount = root.getRight().getSubtreeSize();

        if (leftCount - rightCount > 1)
            root = rotateRight(root);

        else if (leftCount - rightCount < -1)
            root = rotateLeft(root);

        return root;
    }

    private NodeWritable rotateRight(NodeWritable root) {
        NodeWritable pivot = root.getLeft();
        root.setLeft(pivot.getRight());
        pivot.setRight(root);
        updateSubtreeCount(root);
        updateSubtreeCount(pivot);

        return pivot;
    }

    private NodeWritable rotateLeft(NodeWritable root) {
        NodeWritable pivot = root.getRight();
        root.setRight(pivot.getLeft());
        pivot.setLeft(root);
        updateSubtreeCount(root);
        updateSubtreeCount(pivot);

        return pivot;
    }

    private void updateSubtreeCount(NodeWritable node) {
        int leftSize = 0;
        int rightSize = 0;
        int nodeSize;

        if (node.getLeft() != null)
            leftSize = node.getLeft().getSubtreeSize();
        if (node.getRight() != null)
            rightSize = node.getRight().getSubtreeSize();

        if (leftSize >= rightSize)
            nodeSize = leftSize + 1;
        else
            nodeSize = rightSize + 1;

        node.setSubtreeSize(nodeSize);
    }

    public WordTree() {
        root = null;
    }

    public void print() {
        printR(root);
    }

    private void printR(NodeWritable node) {
        if (node == null)
            return;
        printR(node.getLeft());
        System.out.println(node.displayInfo());
        printR(node.getRight());
    }

    public void promptSearch() {
        Scanner scan = new Scanner(System.in);
        String word;

        while (true) {
            System.out.print("\nDigite a palavra que deseja buscar: ");
            word = scan.next();

            if (word.equalsIgnoreCase("!exit")
                    || word.equalsIgnoreCase("!quit"))
                break;
            NodeWritable node = search(word);

            if (node == null) {
                System.out.println("Nenhuma ocorrencia encontrada!");
            } else
                System.out.println(node);
        }

    }

    private NodeWritable search(String word) {
        NodeWritable node = root;

        while (node != null) {
            int compareValue = node.getWord().compareToIgnoreCase(word);
            if (compareValue == 0) {
                break;
            }
            if (compareValue < 0)
                node = node.getRight();
            else
                node = node.getLeft();
        }

        return node;
    }
}
